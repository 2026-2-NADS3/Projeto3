
# variaveis
ORIGEM="$1"
DESTINO="$2"
MANTER=3
LOG="logs/backup.log"
DATA=$(date +%Y-%m-%d_%H-%M-%S)
ARQUIVO="$DESTINO/backup_$DATA.tar.gz"

# cria a pasta do log se ainda nao existir
mkdir -p logs

# confere se passou os 2 argumentos
if [ "$#" -ne 2 ]; then
    echo "Uso: $0 <pasta_origem> <pasta_destino>" >&2
    echo "[$(date '+%d/%m/%Y %H:%M:%S')] ERRO: uso incorreto" >> "$LOG"
    exit 2
fi

# confere se a pasta de origem existe
if [ ! -d "$ORIGEM" ]; then
    echo "Erro: a pasta $ORIGEM nao existe" >&2
    echo "[$(date '+%d/%m/%Y %H:%M:%S')] ERRO: origem nao existe: $ORIGEM" >> "$LOG"
    exit 1
fi

# se a pasta de destino nao existir, cria ela
if [ ! -d "$DESTINO" ]; then
    mkdir -p "$DESTINO"
    echo "[$(date '+%d/%m/%Y %H:%M:%S')] pasta $DESTINO criada" >> "$LOG"
fi

# compacta a pasta com o tar
tar -czf "$ARQUIVO" "$ORIGEM"

# $? guarda o resultado do ultimo comando (0 = funcionou)
if [ $? -ne 0 ]; then
    echo "Erro: nao consegui criar o backup" >&2
    echo "[$(date '+%d/%m/%Y %H:%M:%S')] ERRO: falha no tar" >> "$LOG"
    exit 3
fi

# confere se o backup ficou completo
# conta os itens da origem e do backup, os dois tem que ser iguais
ITENS_ORIGEM=$(find "$ORIGEM" | wc -l)
ITENS_BACKUP=$(tar -tzf "$ARQUIVO" | wc -l)

if [ "$ITENS_ORIGEM" -ne "$ITENS_BACKUP" ]; then
    echo "Erro: o backup nao bateu com a origem ($ITENS_ORIGEM x $ITENS_BACKUP)" >&2
    echo "[$(date '+%d/%m/%Y %H:%M:%S')] ERRO: backup incompleto" >> "$LOG"
    exit 3
fi

echo "[$(date '+%d/%m/%Y %H:%M:%S')] backup criado: $ARQUIVO ($ITENS_BACKUP itens)" >> "$LOG"

# apaga os backups mais velhos, deixando so os 3 ultimos
# como o nome tem a data, o ls ja mostra o mais antigo primeiro
TOTAL=$(ls "$DESTINO"/backup_*.tar.gz | wc -l)

while [ "$TOTAL" -gt "$MANTER" ]; do
    MAIS_ANTIGO=$(ls "$DESTINO"/backup_*.tar.gz | head -n 1)
    rm "$MAIS_ANTIGO"
    echo "[$(date '+%d/%m/%Y %H:%M:%S')] apagado: $MAIS_ANTIGO" >> "$LOG"
    TOTAL=$(ls "$DESTINO"/backup_*.tar.gz | wc -l)
done

# se chegou ate aqui deu tudo certo
echo "Backup feito: $ARQUIVO"
echo "[$(date '+%d/%m/%Y %H:%M:%S')] SUCESSO" >> "$LOG"
exit 0
