package com.example.projeto_pi

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

// Adapter que liga a lista de AgendaItem ao RecyclerView (item_agenda.xml)
class AgendaAdapter(private val itens: List<AgendaItem>) :
    RecyclerView.Adapter<AgendaAdapter.AgendaViewHolder>() {

    class AgendaViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvMes: TextView = view.findViewById(R.id.tvMes)
        val tvDia: TextView = view.findViewById(R.id.tvDia)
        val tvTitulo: TextView = view.findViewById(R.id.tvTitulo)
        val tvHorario: TextView = view.findViewById(R.id.tvHorario)
        val tvLocal: TextView = view.findViewById(R.id.tvLocal)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AgendaViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_agenda, parent, false)
        return AgendaViewHolder(view)
    }

    override fun onBindViewHolder(holder: AgendaViewHolder, position: Int) {
        val item = itens[position]
        holder.tvMes.text = item.mes
        holder.tvDia.text = item.dia
        holder.tvTitulo.text = item.titulo
        holder.tvHorario.text = item.horario
        holder.tvLocal.text = item.local
    }

    override fun getItemCount(): Int = itens.size
}