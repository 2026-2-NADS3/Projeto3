package com.example.projeto_pi

import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.RecyclerView

// Tela inicial (Home): mostra o cartão "Sua Jornada" e a Agenda do aluno.
// É aqui que fica a função principal do app: visualização de cursos e agenda.
class HomeFragment : Fragment(R.layout.fragment_home) {

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val rvAgenda = view.findViewById<RecyclerView>(R.id.rvAgenda)
        rvAgenda.adapter = AgendaAdapter(carregarAgenda())
    }

    // Carrega os itens da agenda (por enquanto fixo; depois pode vir de uma API/BD)
    private fun carregarAgenda(): List<AgendaItem> {
        return listOf(
            AgendaItem("SET.", "21", "Aula: Preparatório ENEM", "19:00", "Online"),
            AgendaItem("SET.", "25", "Encontro 3: Áreas do Conhecimento", "19:00", "Fecap"),
            AgendaItem("SET.", "30", "Aula: Repertorio Argumentativo", "20:00", "Online")
        )
    }
}