package com.example.projeto_pi

// Representa um item da agenda do aluno (data class = só guarda dados)
data class AgendaItem(
    val mes: String,
    val dia: String,
    val titulo: String,
    val horario: String,
    val local: String
)