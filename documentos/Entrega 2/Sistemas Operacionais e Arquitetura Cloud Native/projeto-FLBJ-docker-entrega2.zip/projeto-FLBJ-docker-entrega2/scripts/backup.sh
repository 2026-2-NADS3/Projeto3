
DESTINO="backups"
LOG="logs/backup.log"
MANTER="${MANTER:-3}"
DATA=$(date +%Y-%m-%d_%H-%M-%S)
ARQUIVO="$DESTINO/backup_$DATA.sql"

mkdir -p "$DESTINO" logs

if [ -z "$BANCO_HOST" ] || [ -z "$POSTGRES_DB" ] || [ -z "$POSTGRES_USER" ]; then
    echo "Erro: faltou variavel de ambiente (confira o arquivo .env)" >&2
    echo "[$(date '+%d/%m/%Y %H:%M:%S')] ERRO: faltou variavel de ambiente" >> "$LOG"
    exit 2
fi

psql -h "$BANCO_HOST" -U "$POSTGRES_USER" -d "$POSTGRES_DB" -c "SELECT 1;" > /dev/null 2>&1

if [ $? -ne 0 ]; then
    echo "Erro: o banco $BANCO_HOST nao respondeu" >&2
    echo "[$(date '+%d/%m/%Y %H:%M:%S')] ERRO: banco nao respondeu" >> "$LOG"
    exit 1
fi

pg_dump -h "$BANCO_HOST" -U "$POSTGRES_USER" -d "$POSTGRES_DB" -f "$ARQUIVO"

if [ $? -ne 0 ]; then
    echo "Erro: o pg_dump falhou" >&2
    echo "[$(date '+%d/%m/%Y %H:%M:%S')] ERRO: falha no pg_dump" >> "$LOG"
    rm -f "$ARQUIVO"
    exit 3
fi

TABELAS_BANCO=$(psql -h "$BANCO_HOST" -U "$POSTGRES_USER" -d "$POSTGRES_DB" -t -c "SELECT count(*) FROM pg_tables WHERE schemaname = 'public';" | tr -d ' ')
TABELAS_BACKUP=$(grep -c "CREATE TABLE" "$ARQUIVO")

if [ "$TABELAS_BANCO" -ne "$TABELAS_BACKUP" ]; then
    echo "Erro: o backup nao bateu com o banco ($TABELAS_BANCO x $TABELAS_BACKUP)" >&2
    echo "[$(date '+%d/%m/%Y %H:%M:%S')] ERRO: backup incompleto" >> "$LOG"
    exit 3
fi

gzip "$ARQUIVO"
ARQUIVO="$ARQUIVO.gz"

echo "[$(date '+%d/%m/%Y %H:%M:%S')] backup criado: $ARQUIVO ($TABELAS_BACKUP tabelas)" >> "$LOG"

TOTAL=$(ls "$DESTINO"/backup_*.sql.gz | wc -l)

while [ "$TOTAL" -gt "$MANTER" ]; do
    MAIS_ANTIGO=$(ls "$DESTINO"/backup_*.sql.gz | head -n 1)
    rm "$MAIS_ANTIGO"
    echo "[$(date '+%d/%m/%Y %H:%M:%S')] apagado: $MAIS_ANTIGO" >> "$LOG"
    TOTAL=$(ls "$DESTINO"/backup_*.sql.gz | wc -l)
done

echo "Backup feito: $ARQUIVO"
echo "[$(date '+%d/%m/%Y %H:%M:%S')] SUCESSO" >> "$LOG"
exit 0

