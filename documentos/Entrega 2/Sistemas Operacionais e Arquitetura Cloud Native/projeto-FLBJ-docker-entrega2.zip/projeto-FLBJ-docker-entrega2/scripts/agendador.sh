
INTERVALO="${INTERVALO:-60}"

echo "Agendador iniciado: backup a cada $INTERVALO segundos"

while true; do
    ./scripts/backup.sh
    echo "Codigo de saida do backup: $?"
    sleep "$INTERVALO"
done
