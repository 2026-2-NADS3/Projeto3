
CREATE TABLE alunos (
    id    SERIAL PRIMARY KEY,
    nome  VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL
);
CREATE TABLE cursos (
    id            SERIAL PRIMARY KEY,
    nome          VARCHAR(100) NOT NULL,
    carga_horaria INTEGER NOT NULL
);

CREATE TABLE presencas (
    id       SERIAL PRIMARY KEY,
    aluno_id INTEGER NOT NULL,
    curso_id INTEGER NOT NULL,
    data     DATE NOT NULL
);

INSERT INTO alunos (nome, email) VALUES
    ('Fátima 1', 'fatima1@exemplo.com'),
    ('Luiza  2', 'luiza2@exemplo.com'),
    ('Bruno  3', 'bruno3@exemplo.com');

INSERT INTO cursos (nome, carga_horaria) VALUES
    ('Orientacao Profissional', 20),
    ('Financas Pessoais', 12);

INSERT INTO presencas (aluno_id, curso_id, data) VALUES
    (1, 1, '2026-09-20'),
    (2, 1, '2026-09-20'),
    (3, 2, '2026-09-27');

